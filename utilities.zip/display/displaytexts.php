<?php
    class Text{
        private $servername = "localhost";
        private $username = "root";
        private $password = "";
        private $database = "user";
        public $con;

        //Create connection string (Database connection)
        public function __construct(){
            $this->con = new mysqli($this->servername, $this->username, $this->password, $this->database);
            if (mysqli_connect_error()){
                trigger_error("Not possible to connect to MySQL: ".mysqli_connect_error());
            }
            else{
                return $this->con;
            }
            
        }


       public function displayRecordById($id)
       {
           $query = "SELECT * FROM texts WHERE id = '$id'";
           $result = $this->con->query($query);
           if($result->num_rows > 0){
               $data = $result->fetch_assoc();           
               return $data;
           }
           else{
               echo "Record not found";
           }
       }
   
    }
?>