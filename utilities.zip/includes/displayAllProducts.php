<?php
    $counter = 0;
        include "includes/displaySneakers.php";
        $sneakersObj = new Sneakers();
        $sneakers = $sneakersObj->displayData(); 
        foreach ($sneakers as $sneakerss) {
        $counter ++;
      ?>
         <div class="col-md-3 col-6 py-2">
            <div class="card">
                <img src="<?php echo $sneakerss['image']?>" alt="" class="img-fluid pb-1" >
                <div class="figure-caption">
                    <h6><?php echo $sneakerss['title'] ?></h6>
                    <h6><?php echo $sneakerss['price'] ?></h6>
                    <p><a href='products.php?hello<?php echo $sneakerss['id']?>=true' role="button" class="btn btn-warning  text-white ">Add To Cart</a></p>
                    <p><a href='edit.php?editId=<?php echo $sneakerss['id'] ?>' role="button" class="btn btn-warning  text-white ">Edit</a></p>
                </div>
            </div>
        </div>
        <?php } 
?>


