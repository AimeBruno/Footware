<footer class="footer" style="left:0;">
    <div class="container text-center"><span class="text-muted"><b style="color:white;">Copyright&copy;Footwear | All Rights Reserved | Contact Us at: +514 123 4567</b></span></div>
</footer>
    