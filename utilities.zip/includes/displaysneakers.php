<?php
    class Sneakers{
        private $servername = "localhost";
        private $username = "root";
        private $password = "";
        private $database = "user";
        public $con;

        //Create connection string (Database connection)
        public function __construct(){
            $this->con = new mysqli($this->servername, $this->username, $this->password, $this->database);
            if (mysqli_connect_error()){
                trigger_error("Not possible to connect to MySQL: ".mysqli_connect_error());
            }
            else{
                return $this->con;
            }
            
        }


       // Fetching customer records
       public function displayData() {
        // check if param page exists or not
        if (isset($_GET['p']) && $_GET['p']!="") {
            $page = $_GET['p'];
        } else {
            $page = 1;
        }

        $total_records_per_page = 4;
        $offset = ($page - 1) * $total_records_per_page;

        $query = "SELECT * FROM product_display LIMIT $offset, $total_records_per_page";
        $result = $this->con->query($query);
        if($result->num_rows > 0){
            $data = array();
            while($row = $result->fetch_assoc()){
                $data[] = $row;
            }
            return $data;
        }
        else{
            echo "No found records";
        }
   }


   public function displayRecordById($id)
   {
       $query = "SELECT * FROM product_display WHERE id = '$id'";
       $result = $this->con->query($query);
       if($result->num_rows > 0){
           $data = $result->fetch_assoc();           
           return $data;
       }
       else{
           echo "Record not found";
       }
   }


   public function updateRecord($postData)
   {
       $title = $this->con->real_escape_string($_POST['title']);
       $price = $this->con->real_escape_string($_POST['price']);
       $id = $this->con->real_escape_string($_POST['id']);
       if(!empty($id) && !empty($postData)){
           $query = "UPDATE product_display SET title = '$title', price= '$price' WHERE id = '$id'";
           $sql = $this->con->query($query);
           if($sql==true)
           {
               header("Location:products.php");
           }
           else{
               echo "Failed to update, try again!";
           }
       }

   }
}
?>