<?php
            include 'display/displaytexts.php';

            $textObj = new Text();
            $text = $textObj->displayRecordById(3); 


?>
<nav class="navbar fixed-top navbar-expand-sm navbar-dark" style="background-color:rgba(0,0,0,0.5)">
            <div class="container">
                    <a href="index.php" class="navbar-brand" style="font-family: 'Roboto', sans-serif;"><?php echo $text['text1']?></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynavbar">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                <div class="collapse navbar-collapse" id="mynavbar">
                    <ul class="nav navbar-nav">
                  
                       <li class="nav-item"><a href="products.php" class="nav-link"><?php echo $text['text2']?></a></li>
                       <li class="nav-item"><a href="about.php" class="nav-link"><?php echo $text['text3']?></a></li>
                       <?php
                       if (isset($_SESSION['email'])) {
                            $con = mysqli_connect('localhost', 'root', '', 'user');
                            $sql = "SELECT * FROM product WHERE user= '".$_SESSION["email"]."'";
                            $result = mysqli_query($con , $sql);
                            $total = mysqli_num_rows($result);
                        ?>
                       <li class="nav-item"><a href="cart.php" class="nav-link"><?php echo $text['text4']?> <span style="color:white">(<?php echo $total ?>)</span></a></li>
                       <?php
                          } 
                       ?>
                    </ul>
                    
                    <?php
                    if (isset($_SESSION['email'])) {
                    ?>
                    <ul class="nav navbar-nav ml-auto">
                       <li class="nav-item"><a href="signout.php" class="nav-link"><i class="fa fa-sign-out"></i><?php echo $text['text5']?></a></li>
                       <li class="nav-item"><a  class="nav-link " data-placement="bottom" data-toggle="popover" data-trigger="hover" data-content="<?php echo $_SESSION['email'] ?>"><?php echo $_SESSION['email'] ?></i></a></li>
                    </ul>
                    <?php
                } else {
                    ?>
                    <ul class="nav navbar-nav ml-auto">
                       <li class="nav-item "><a href="signup.php" class="nav-link"data-toggle="modal" ><i class="fa fa-user"></i> <?php echo $text['text6']?></a></li>
                       <li class="nav-item "><a href="login.php" class="nav-link" data-toggle="modal"><i class="fa fa-sign-in"></i> <?php echo $text['text7']?></a></li>
                    </ul>
                    <?php 
                }
                    ?>
                </div>
            </div>
</nav>


