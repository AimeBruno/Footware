<?php
    class Text{
        private $servername = "localhost";
        private $username = "root";
        private $password = "";
        private $database = "user";
        public $con;

        //Create connection string (Database connection)
        public function __construct(){
            $this->con = new mysqli($this->servername, $this->username, $this->password, $this->database);
            if (mysqli_connect_error()){
                trigger_error("Not possible to connect to MySQL: ".mysqli_connect_error());
            }
            else{
                return $this->con;
            }
            
        }


       // Fetching customer records
       public function displayData()
       {
           $query = "SELECT * FROM about_page"; 
           $result = $this->con->query($query);
           if($result->num_rows > 0){
               $data = array();
               while($row = $result->fetch_assoc()){
                   $data[] = $row;
               }
               return $data;
           }
           else{
               echo "No found records";
           }
       }
   
    }
?>